clc;
clear all;
close all;

%Reading image from file
I = imread('walking.jpg'); 
%Detecting p'walking.jpg'eople in an image using Computer Vision Toolbox function
detector = peopleDetectorACF;
[bboxes,scores] = detect(detector,I);
nofpeople = length(scores);
%Annotating the image
I = insertObjectAnnotation(I,'rectangle',bboxes,scores);
%Displaying the results
figure
imshow(I);
title([num2str(nofpeople), ' Detected People and Detection Scores']);